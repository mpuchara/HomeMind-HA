"""Differential check of the diagnostic admission branch probes."""
import unittest
from contextlib import ExitStack, nullcontext
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import support
import universal_history_collector as collector
from tools.trace_preparation_scheduler import install
from universal_predecision import PredecisionEvidence


class SchedulerProbeTests(unittest.TestCase):
    def test_crossing_foreground_deadline_rechecks_before_poll(self):
        path = Path(__file__).parent/'reference/collector_scheduler_9c245577.py'
        namespace = dict(vars(collector))
        exec(compile(path.read_text(), str(path), 'exec'), namespace)
        original = namespace['_run']

        def replay(run, *, budget_ready_at, active=False, retry_delay=0.):
            now = [.295]
            calls = []
            budget = collector.PreparationBudget(lambda: now[0])
            budget.ready_at = budget_ready_at
            engine = SimpleNamespace(in_flight={})
            owner = SimpleNamespace(
                predecision=SimpleNamespace(pending={'root': None}, engine=engine),
                ready=SimpleNamespace(set=lambda: None), pending=[object()], pending_gap=None,
                stopping=False, preparation_budget=budget, stats={'errors': 0},
                clock=lambda: now[0], session='test', _close=lambda *a: None,
                retry=SimpleNamespace(delay=lambda: retry_delay if now[0] >= .325 else 0.),
                halt=SimpleNamespace(wait=lambda delay: now.__setitem__(0, now[0]+delay)))

            class Condition:
                def __enter__(self):
                    return self

                def __exit__(self, *unused):
                    return False

                def wait(self, delay):
                    calls.append(('poll', round(delay, 3)))
                    if active or retry_delay:
                        owner.stopping = True
                    now[0] += delay

            def drain(*, foreground=False):
                calls.append(('drain', foreground))
                owner.pending.clear()
                if foreground:
                    now[0] = .325
                return True

            def prepare():
                calls.append(('prepare', round(now[0], 3)))
                owner.stopping = True

            owner.cv = Condition()
            owner.drain = drain
            owner._prepare_turn = prepare
            owner.idle_ready = lambda: now[0] >= .3 and not active
            owner._idle_wait = lambda: collector.HistoricalTrainingCollector._idle_wait(owner)
            owner.journal = SimpleNamespace(flush_pending_prune=lambda **_: None)
            owner.store = SimpleNamespace(background_sqlite=lambda **_: nullcontext(),
                                          conn=lambda: nullcontext(SimpleNamespace(execute=lambda *a: None)))
            with patch.object(collector, 'foreground_priority_remaining', lambda _: .3-now[0]):
                run(owner)
            return calls

        candidate = collector.HistoricalTrainingCollector._run
        self.assertEqual(replay(original, budget_ready_at=0.), [
            ('drain', True), ('poll', .25), ('drain', False), ('prepare', .58)])
        self.assertEqual(replay(candidate, budget_ready_at=0.), [
            ('drain', True), ('drain', False), ('prepare', .33)])
        for constraints in (dict(budget_ready_at=.4), dict(budget_ready_at=0., active=True),
                            dict(budget_ready_at=0., retry_delay=.02)):
            self.assertEqual(replay(candidate, **constraints), replay(original, **constraints))

    def test_admission_and_budget_match_uninstrumented_turn(self):
        original = collector.HistoricalTrainingCollector._prepare_turn

        def replay(turn, *, idle, pending, ready_at, outcome):
            now = [10.]
            calls = []
            budget = collector.PreparationBudget(lambda: now[0])
            budget.ready_at = ready_at

            def prepare():
                calls.append('prepare')
                if outcome == 'exception':
                    now[0] += .02
                    raise RuntimeError('synthetic preparation exception')
                if outcome == 'completed':
                    now[0] += .02

            def idle_ready():
                calls.append('idle')
                return idle

            owner = SimpleNamespace(
                predecision=SimpleNamespace(pending={'root': None} if pending else {},
                                           engine=SimpleNamespace(in_flight={}),
                                           prepare_one=prepare, stats={'errors': 0}),
                pending=[], stopping=False, idle_ready=idle_ready, preparation_budget=budget,
                retry=SimpleNamespace(delay=lambda: 0.),
                store=SimpleNamespace(background_sqlite=lambda **_: nullcontext()),
                preparation_stats=dict(budget_deferrals=0, wall_seconds=0., thread_cpu_seconds=0., turns=0))
            turn(owner)
            stats = dict(owner.preparation_stats)
            stats.pop('thread_cpu_seconds')
            return calls, stats, budget.ready_at, owner.predecision.stats

        cases = (
            dict(idle=False, pending=True, ready_at=0., outcome='completed'),
            dict(idle=True, pending=False, ready_at=0., outcome='completed'),
            dict(idle=True, pending=True, ready_at=10.1, outcome='completed'),
            dict(idle=True, pending=True, ready_at=0., outcome='completed'),
            dict(idle=True, pending=True, ready_at=0., outcome='noop'),
            dict(idle=True, pending=True, ready_at=0., outcome='exception'),
        )
        with ExitStack() as stack:
            records = []
            install(stack, patch, collector, PredecisionEvidence,
                    lambda kind, **fields: records.append((kind, fields)))
            probed = collector.HistoricalTrainingCollector._prepare_turn
            for case in cases:
                with self.subTest(**case):
                    self.assertEqual(replay(original, **case), replay(probed, **case))
            kinds = [kind for kind, _ in records]
            self.assertEqual(kinds.count('budget_debt'), 1)
            self.assertEqual(kinds.count('attempt'), 3)


if __name__ == '__main__':
    unittest.main()
