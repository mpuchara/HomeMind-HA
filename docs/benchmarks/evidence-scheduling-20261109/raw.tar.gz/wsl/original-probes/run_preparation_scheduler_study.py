"""Run the six Normal same-revision pairs with opt-in scheduler tracing."""
import argparse
import hashlib
import os
import subprocess
import sys
from pathlib import Path

from run_gate_d_snapshot_study import manifest, save


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--pairs', type=int, default=6)
    args = parser.parse_args()
    args.output.mkdir()
    probe = Path(__file__).with_name('trace_evidence_availability.py')
    save(args.output/'protocol.json', dict(
        source='9c245577727c93ede3c59100f11844bf336acb1a', manifest=manifest(args.source),
        probes={path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                for path in (probe, probe.with_name('trace_preparation_scheduler.py'))},
        pairs=args.pairs, diagnostic_only=True))
    for index in range(args.pairs):
        for role in (('base', 'source') if index % 2 == 0 else ('source', 'base')):
            prefix = args.output/f'normal-{index+1}-{role}'
            command = [sys.executable, str(probe), str(args.source), str(prefix.with_suffix('.trace.json')),
                       '--scheduler', '--cases', '1000:200', '--modes', 'normal', '--candidates', '0',
                       '--ticks', '24', '--period', '.4', '--fanout', '16',
                       '--output', str(prefix.with_suffix('.jsonl'))]
            before = os.getloadavg()
            with prefix.with_suffix('.log').open('xb') as log:
                code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=420).returncode
            save(prefix.with_suffix('.receipt.json'), dict(command=command, exit_code=code,
                                                             load_before=before, load_after=os.getloadavg()))
            print(prefix.name, code, flush=True)
            if code:
                return code
    return 0


if __name__ == '__main__':
    sys.exit(main())
