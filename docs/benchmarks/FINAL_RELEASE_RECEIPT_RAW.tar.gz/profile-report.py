import json,pathlib
r=pathlib.Path('/home/mpuchara/homemind-receipt-study-20261106')
p=pathlib.Path('/mnt/c/Users/mpuch/OneDrive/Dokumenty/HomeMind/HomeMind-HA-universal-232/docs/FINAL_RELEASE_RECEIPT_CPU_PROFILE.md')
summary=json.load(open(r/'profile-summary.json'))
lines=['\n## Final common-probe results\n','All CPU values below are instrumented milliseconds. Complete receipt counts are','the final persisted native inventory; load captures/outer encodes can be fewer','because the final drain is separate. No profiled value is an acceptance result.\n','| Workload/arm | Setup CPU | Load CPU | Finalization CPU | Load batches | Load outer encodes | Final decisions / complete V2 | CPU/load batch |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for name,row in sorted(summary['diagnostics_only'].items()):
 raw=json.load(open(r/'profiles'/(name+'.profile.json')))
 phase=row['phases'];load=phase['load'];c=row['counts']
 enc=max((v[0] for k,v in raw['rows'].items() if k.startswith('load/universal_history_collector.HistoricalTrainingCollector._write:') and k.endswith(':encoded')),default=0)
 lines.append(f"| {name} | {phase['setup']['writer_cpu_ms']:.2f} | {load['writer_cpu_ms']:.2f} | {phase['finalization']['writer_cpu_ms']:.2f} | {load['writer_calls']} | {enc} | {c['written_decisions']} / {c['v2_receipts']} | {load['cpu_ms_per_batch']:.3f} |")
lines+=['\nThe per-site raw rows also permit CPU per outer decision encode or complete','capture. Dividing total writer CPU by only qualified receipts would conflate','unqualified decisions, native observations, barriers, transaction setup and','retries; it is not an estimate of marginal qualification cost.\n','| Workload/arm | Load SELECT | Load PRAGMA | Load BEGIN / COMMIT | Load INSERT / UPDATE / DELETE | Source revisions (reads) | Distinct declaration / topology lookups |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for name,row in sorted(summary['diagnostics_only'].items()):
 sql=row['sql_trace_events'];s=lambda k:sql.get('load/'+k,0)
 rev=row['source_revision_counts'] or {}; dec=row['declaration_revision_counts'] or {};top=row['topology_revision_counts'] or {}
 lines.append(f"| {name} | {s('SELECT')} | {s('PRAGMA')} | {s('BEGIN')} / {s('COMMIT')} | {s('INSERT')} / {s('UPDATE')} / {s('DELETE')} | {len(rev)} ({sum(rev.values())}) | {len(dec)} / {len(top)} |")
lines+=['\nThese are callback events, including trigger expansion and diagnostic protection','queries. A BEGIN/COMMIT count difference is not by itself proof of a lost','transaction: retry/exception and phase-boundary details remain in raw rows.','Distinct declaration hashes reflect different agents as well as potential changes;','they must not be presented as a count of declaration mutations.\n','### Component breakdown of the two previous-production loads\n','Calls / inclusive / exclusive CPU are retained for every measured site in the raw','profiles. The following largest exclusive sites show where the remaining writer','CPU goes (including probe residual).\n']
for name in ('small50-before','normal-before'):
 row=summary['diagnostics_only'][name]
 lines+=['**'+name+'**\n','| Site | Calls | Inclusive ms | Exclusive ms |','| --- | ---: | ---: | ---: |']
 for key,v in row['phases']['load']['exclusive_top'][:12]:
  lines.append(f'| `{key}` | {v[0]} | {v[1]/1e6:.3f} | {v[2]/1e6:.3f} |')
 lines.append('')
protocol=json.load(open(r/'protocol.json'))
lines+=['## Fingerprints\n','Full normalized Python manifests precede the final common-probe runs in','`protocol.json`. The registered matrix additionally freezes its own manifests.','Baseline/previous/candidate sources are independent disposable ext4 trees.\n', '- Common harness SHA-256: `'+protocol['manifests']['source']['tools/benchmark_qualified_evidence.py']+'`.', '- Common fixture SHA-256: `'+protocol['manifests']['source']['tools/universal_e2e_fixture.py']+'`.', '- Diagnostic probe SHA-256: `'+protocol['probe_sha256']+'`.\n']
with p.open('a') as out:out.write('\n'.join(lines))
