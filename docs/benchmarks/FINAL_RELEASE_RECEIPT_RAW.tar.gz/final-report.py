import json,pathlib
r=pathlib.Path('/home/mpuchara/homemind-receipt-study-20261106')
docs=pathlib.Path('/mnt/c/Users/mpuch/OneDrive/Dokumenty/HomeMind/HomeMind-HA-universal-232/docs')
x=json.load(open(r/'summary.json'))
def table(rows):
 lines=['| Pair | CPU | p95 | p99 | RSS | Consumed | Qualified | Screen |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
 for row in rows:
  v=row['ratios']; nums=[f'{v[k]*100:+.2f}%' for k in ('cpu','p95','p99','rss')]
  lines.append('| '+' | '.join([row['name'],*nums,' -> '.join(map(str,row['consumed'])),' -> '.join(map(str,row['qualified'])),row['status']])+' |')
 return '\n'.join(lines)
opt=docs/'FINAL_RELEASE_RECEIPT_OPTIMIZATION.md'
text=opt.read_text().replace('Final results and disposition are recorded below when the frozen study ends.','')
text+='''
## Rejected experiment and restored production

**REJECTED**, with runtime restored by `c1dbfd9fd468a9ea24c114cdaf044fbe5b0d8244`.
The restored add-on tree is `cd0c22a0193f91cc3b9ac7dc7e477dbf73aa7f0f`, exactly
identical to `9c245577`. The experimental `4dc2d2d6` source remains immutable in
Git and the ext4 study; later reporting/tool changes do not alter that source.
The optimization was reverted once the unprofiled screening failed to demonstrate
repeatable process-CPU savings. Its full registered matrix continued on the
already frozen ext4 source, independently of the Windows worktree restoration.
No timing measurement was run on a moving source.

Pure validation microbenchmarks (six alternating pairs, 2,000 validations per
arm) show reduced CPU in every pair: 43.2–56.7% at 50 sensors, 94.5–96.0% at 1,000.
They exclude native work and preparation of the derived input; they are not
writer or process acceptance. The previous-production screen is the controlling
causal comparison for retaining this isolated optimization:

'''+table(x['screen'])+'''

All screen pairs preserve original inputs/signatures, native evidence accounting
and zero unauthorized HA calls/errors/drops. Small50 pair 2 has load batches
50 -> 53 and preparation CPU 32.892 -> 50.365 ms, with the same 20 turns and
175 consumed/qualified receipts. Pair 1 has 52 -> 52 load batches and preparation
CPU 45.063 -> 41.515 ms. Both have an empty Busy-work dictionary. Normal screen
load batches are 164 -> 168 and 162 -> 167; preparation CPU is 380.560 -> 389.338 ms
and 352.942 -> 394.529 ms. These real activity differences are recorded, not
normalized away. They do not establish a reproducible environment defect.

## Complete registered Gate D result for the rejected candidate

**11/13 timing screens PASS; Gate D BLOCKER.** Exact #368 is the baseline.
The complete original 26-arm protocol finished with unchanged margins and
workloads; no failed pair was averaged away or discarded.

'''+table(x['matrix'])+'''

Primary consumed **41 -> 99**, qualified **39 -> 95**: both exceed 2x.
Including the supported small workloads, consumed **187 -> 365** and qualified
**185 -> 361**: both are **below 2x**. Every individual active supported workload
improves, but that does not waive either aggregate or CPU limits. The two failed
CPU margins are 50/10 **+16.057%** and 200/30 **+16.121%** (limit +15%).

All 26 arms have matching fingerprints/original decision signatures and exact
original decision counts, zero HA service calls, zero collector errors/drops and
zero event drops. Native decision/provenance counts and fail-closed controls pass
in every arm. Unsupported 400 remains unqualified with `agent bound`; a passing
unsupported timing screen does not qualify that cardinality.

Failed-workload investigation: 50/10 process CPU is 0.424802 -> 0.493014 s,
load batches 26 -> 50, consumed/qualified 100 -> 158; candidate preparation uses
20 turns / 45.370 ms CPU. 200/30 CPU is 0.697686 -> 0.810162 s, load batches
37 -> 65, consumed/qualified 46 -> 108; candidate preparation uses 30 turns /
120.576 ms CPU. Both workloads have no Busy training jobs. Batch/evidence counts
are real work and are not divided out of the acceptance CPU. Source and harness
integrity checks pass. No independent benchmark-environment defect is established.

## Registered same-revision controls

All six timing screens pass. Both roles execute the exact `4dc2d2d6` source
(the actual receipt commands, not the generic protocol's baseline label, identify
that source). Inputs/signatures and safety accounting match throughout.

'''+table(x['variance'])+'''

Control 4 consumes/qualifies 13 -> 11 despite identical source and input, showing
admission/qualification count variation. These controls neither erase the two
registered CPU failures nor turn the below-2x broader aggregate into PASS.
The prior `9c245577` 9/13 matrix and its four failures remain historical evidence;
they are not attributed to `4dc2d2d6`, and the new results are not attributed to
the restored runtime without another experiment. No cross-series causal speedup
claim is justified by changing the number of passing timing screens.

## Final verification and continuation

Every one of **253 add-on files in each of four trees** (baseline, previous,
experimental and restored validation) matches its exact Git archive. Initial,
registered matrix and variance Python manifests remain unchanged. Harness and
fixture fingerprints match in every arm. `integrity.json` records the proof.
The restored source passes **2 differential tests in 1.566 s** (15 writer subcases)
and **4 native journal tests in 2.317 s** after all timing measurements finish.
Candidate Universal 295 PASS remains a candidate-local result, not release CI.

The largest measured remaining native writer cost is storage-budget sampling,
page accounting and guarded transaction lifecycle, detailed in the CPU report.
Continue inside those original checks: distinguish redundant Python/statement
preparation from required fresh filesystem/page/WAL checks. Preserve every
admission/commit/rollback boundary and run a lightweight CPU attribution before
another isolated optimization. Do not reapply the rejected universe experiment,
change cadence, discard work, relax bounds or redesign receipt bytes.

Reproduction: `profile_native_writer.py` (optional `--profile-storage-budget` is
extra diagnostic overhead), `run_receipt_screen.py`, the unchanged registered
`run_gate_d_snapshot_study.py`, `analyze_receipt_study.py`, and
`verify_receipt_study.py`. `screen_receipt_universe.py` must run on frozen
`4dc2d2d6`; it intentionally refuses the restored runtime. Drivers, commands,
logs, complete JSONL, manifests, failed fixture attempts and all raw profiles are
in `benchmarks/FINAL_RELEASE_RECEIPT_RAW.tar.gz` with adjacent SHA-256;
`FINAL_RELEASE_RECEIPT_SUMMARY.json` contains the parsed matrix and checks.

Candidate Recovery, production composition, actual-installation migration,
inherited intermittent retention/rollback, four-hour soak, release integration
and Pi/live HA remain open. The collector remains default-off. No version bump,
merge, release/tag/ZIP or deployment occurred.
'''
opt.write_text(text)
profile=docs/'FINAL_RELEASE_RECEIPT_CPU_PROFILE.md'
text=profile.read_text().replace('Final common-probe tables, SQL counts and exact fingerprints are recorded below\nafter all frozen arms finish.','Final common-probe tables, SQL counts and exact fingerprints are recorded below.')
text+='''
## Additional native-budget attribution after registered measurements

A separate optional probe runs the previous production `9c245577`, whose add-on
tree is the restored production tree. It preserves the same compatible fixture
and load, with extra method/call instrumentation in `StorageBudget.sample()`,
`check()` and `observe_pages()`. Native connection lifecycle methods are wrapped
without recompiling their closures. Its timings include additional instrumentation
and must not be compared numerically with the lighter probe or acceptance CPU.
Raw source/probe hashes and receipts are in `native-budget/`.

| Load / operation | Calls | Inclusive CPU ms | Exclusive CPU ms |
| --- | ---: | ---: | ---: |
| Normal writer | 134 | 443.224 | 28.352 |
| Normal sample | 619 | 100.982 | 44.981 |
| Normal check | 886 | 102.071 | 22.134 |
| Normal observe_pages | 318 | 73.311 | 21.248 |
| Normal connection exit | 161 | 86.280 | 23.708 |
| 50/10 writer | 52 | 275.353 | 18.128 |
| 50/10 sample | 285 | 33.926 | 15.651 |
| 50/10 check | 462 | 36.996 | 9.179 |
| 50/10 observe_pages | 152 | 15.219 | 6.683 |
| 50/10 connection exit | 79 | 29.569 | 14.540 |

Inclusive rows overlap: checks and connection exits contain some samples/page
accounting. Do not sum all rows. Normal sampling performs **1,238 file-size reads**
(619 database + 619 WAL) and **619 disk-usage reads**. Their call-site CPU is
15.566 + 16.887 ms and 11.268 ms respectively. Reconstructing the WAL Path is
4.349 ms / 619 calls. Page accounting performs **954 native page PRAGMAs**
(318 each for page_count, freelist_count and page_size); execute CPU is
17.275 + 8.045 + 13.183 ms, with fetch/other work recorded separately.
No load-phase explicit commit/rollback/close call is observed: the persistent
worker borrows a connection, and its guarded context exit performs commit.
Setup/finalization lifecycle calls and actually observed SQL verbs remain raw.

**Next proven cost:** fresh storage-budget/filesystem sampling, native page
accounting and guarded transaction entry/exit, rather than receipt-universe
computation. This is a cost attribution, not proof that these checks can be
removed. Required fresh sampling at entry/exit/commit and the 50 ms / 1 MiB
within-batch limits remain authoritative. Investigate redundant Python/statement
preparation while retaining those exact checks. Do not replace their native
values with transaction-local assumptions merely because BEGIN IMMEDIATE is held.
The experimental derived-universe optimization was rejected and restored by
`c1dbfd9f`; the complete failed matrix and continuation are in the optimization
report. Neither this deeper profile nor the pure component speedup closes Gate D.
'''
profile.write_text(text)
checkpoint='''# Receipt CPU investigation checkpoint — 2026-11-06

**Gate D remains BLOCKER.** The isolated derived-universe experiment
`4dc2d2d630aa8ee144c0e7d8492173c462647a34` was implemented, tested and **rejected**:
it has no repeatable process-CPU improvement versus previous production.
Restoration commit `c1dbfd9fd468a9ea24c114cdaf044fbe5b0d8244` returns the add-on tree
to `cd0c22a0193f91cc3b9ac7dc7e477dbf73aa7f0f`, exactly the `9c245577` production tree.
Version **0.14.232** is unchanged. Reporting-only HEAD is recorded in PR #369.

The frozen rejected candidate completed all **13 pairs / 26 arms** against exact
#368 `951dcd70ed20b5f74220307cfb7411fa2c6bcc5d`: **11/13 timing screens PASS**.
All six Normal pairs, both Busy cases and OFF/incomplete/unsupported controls
pass. CPU fails for **50/10 +16.057%** and **200/30 +16.121%** (limit +15%).
Primary consumed/qualified are **41 -> 99 / 39 -> 95** (>2x), while the broader
supported totals **187 -> 365 / 185 -> 361** are **below 2x**. Every active
supported case improves. No failure was averaged away. All six registered
same-revision timing controls pass; one varies consumed/qualified 13 -> 11.

Every input fingerprint/original decision signature/count and native persistence/
provenance check passes, with zero unauthorized HA calls, collector errors/drops
or event drops. Unsupported 400 remains unqualified (`agent bound`). The earlier
`9c245577` 9/13 matrix remains evidence for the restored runtime; the rejected
candidate's matrix does not replace it or prove a cross-series causal speedup.

Candidate local validation: **295 Universal PASS**; corrected positive exact-byte
writer differential **2 PASS / 15 subcases**; journal differential **4 PASS**.
Restored runtime: **2 differential + 4 journal PASS** after timing finishes.
All **253 add-on files in each of four source trees** match exact archives;
original and registered source/harness manifests remain unchanged.

See [CPU profile](FINAL_RELEASE_RECEIPT_CPU_PROFILE.md),
[optimization, full matrix and rejection](FINAL_RELEASE_RECEIPT_OPTIMIZATION.md),
[parsed evidence](benchmarks/FINAL_RELEASE_RECEIPT_SUMMARY.json) and
[raw evidence](benchmarks/FINAL_RELEASE_RECEIPT_RAW.tar.gz) with adjacent SHA-256.
Next measured target is native storage-budget sampling/page accounting and guarded
transaction lifecycle: 619 Normal load samples and 318 page observations in the
extra diagnostic. Preserve fresh native checks, commit/rollback and all cadence,
workload, qualification, receipt-byte and evidence-throughput contracts.

PR #369 stays Draft/open. Collector stays default-off. Candidate Recovery,
production composition, actual-installation migration, inherited intermittent
retention/rollback, four-hour soak, release integration and Pi/live HA remain open.
No merge, version bump, release/tag/ZIP or deployment.

'''
for name in ('FINAL_RELEASE_NATIVE_WRITER.md','FINAL_RELEASE_PERFORMANCE.md','FINAL_RELEASE_READINESS_REPORT.md'):
 p=docs/name;p.write_text(checkpoint+'## Earlier checkpoint (historical)\n\n'+p.read_text())
handoff=checkpoint+'''## Exact continuation

Worktree: `C:\\Users\\mpuch\\OneDrive\\Dokumenty\\HomeMind\\HomeMind-HA-universal-232`.
Branch: `codex/universal-u05b4c1g-evidence-scalability`; Draft PR #369.
Immutable WSL evidence: `/home/mpuchara/homemind-receipt-study-20261106`.
Use `~/homemind-perf-venv/bin/python`.

Fetch and verify clean worktree/actual reporting HEAD. Require an empty
`git diff c1dbfd9f HEAD -- adaptive_ai` for reporting-only changes. Do not repeat
the complete PR inventory, the four completed snapshot/writer optimizations,
the rejected universe experiment or completed acceptance runs without a new cause.
The measured experiment is `4dc2d2d6` / add-on `6cc6c81c21764d9c1b530fbc7cff4bf8ef2295c1`;
the retained runtime is `c1dbfd9f` / add-on `cd0c22a0193f91cc3b9ac7dc7e477dbf73aa7f0f`.
The generic same-revision protocol retains a baseline label, but its actual
receipts execute the candidate source for BOTH roles; all six runs are controls.

Next unfinished implementation action: use the native-budget detail to distinguish
redundant Python/statement setup in `StorageBudget.sample`, `check`,
`observe_pages` and guarded `Store.conn`/connection exit from the required fresh
filesystem/page/WAL samples. Do not cache storage safety values or reduce refresh
points to manufacture a speedup. Establish one bounded safe redundancy, preserve
a frozen oracle, implement one change, and require repeatable unprofiled CPU
benefit against the retained runtime before retaining it. Then rerun the original
complete Gate D protocol against exact #368, including the broader aggregate.
Do not change cadence, training duty cycle, admission or validation limits.

All failed initial fixture/bootstrap attempts and raw measurements are retained.
The corrected positive differential explicitly requires a complete V2 receipt;
SQLite backup schema-cookie restoration is test-copy preparation, not production
verification relaxation. No general verified-native transaction cache was added.
Current local checks and checkpoint CI must be attributed to their exact source;
a green restored-runtime CI does not certify rejected `4dc2d2d6` or a final release.

'''
p=docs/'FINAL_RELEASE_HANDOFF.md';p.write_text(handoff+'## Earlier checkpoint (historical)\n\n'+p.read_text())
