import hashlib,json,subprocess,sys
from pathlib import Path
r=Path('/home/mpuchara/homemind-receipt-study-20261106')
sys.path.insert(0,str(r/'source/tools'))
from run_gate_d_snapshot_study import manifest
arms=('base','before','source')
manifest_data={arm:manifest(r/arm) for arm in arms}
assert len({v['tools/benchmark_qualified_evidence.py'] for v in manifest_data.values()})==1
assert len({v['tools/universal_e2e_fixture.py'] for v in manifest_data.values()})==1
(r/'protocol.json').write_text(json.dumps(dict(baseline='951dcd70ed20b5f74220307cfb7411fa2c6bcc5d',previous='9c245577727c93ede3c59100f11844bf336acb1a',candidate='4dc2d2d630aa8ee144c0e7d8492173c462647a34',candidate_addon='6cc6c81c21764d9c1b530fbc7cff4bf8ef2295c1',manifests=manifest_data,probe_sha256=hashlib.sha256((r/'profile.py').read_bytes()).hexdigest(),serial=True),indent=2))
for workload,scale in [('small50','50:10'),('normal','1000:200')]:
 for arm in arms:
  name=workload+'-'+arm
  cmd=[sys.executable,str(r/'profile.py'),'--source-root',str(r/arm),'--harness',str(r/arm/'tools/benchmark_qualified_evidence.py'),'--profile-output',str(r/'profiles'/(name+'.profile.json')),'--cases',scale,'--modes','normal','--ticks','24','--period','.4','--fanout','16','--output',str(r/'profiles'/(name+'.jsonl'))]
  with (r/'profiles'/(name+'.log')).open('x') as out: code=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=420).returncode
  (r/'profiles'/(name+'.receipt.json')).write_text(json.dumps(dict(command=cmd,exit_code=code)))
  print(name,code,flush=True)
  if code:raise SystemExit(code)
for phase,cmd in [('screen',[str(r/'source/tools/run_receipt_screen.py'),str(r)]),('matrix',[str(r/'source/tools/run_gate_d_snapshot_study.py'),str(r),'--phase','matrix','--candidate-sha','4dc2d2d630aa8ee144c0e7d8492173c462647a34'])]:
 with (r/(phase+'-progress.log')).open('x') as log:code=subprocess.run([sys.executable,*cmd],stdout=log,stderr=subprocess.STDOUT).returncode
 print(phase,code,flush=True)
 if code:raise SystemExit(code)
rows=json.loads((r/'matrix/summary.json').read_text())
if any(row['status']=='FAIL' for row in rows):
 with (r/'variance-progress.log').open('x') as log:
  code=subprocess.run([sys.executable,str(r/'source/tools/run_gate_d_snapshot_study.py'),str(r),'--phase','variance','--candidate-sha','4dc2d2d630aa8ee144c0e7d8492173c462647a34'],stdout=log,stderr=subprocess.STDOUT).returncode
 print('variance',code,flush=True)
 if code:raise SystemExit(code)
(r/'post-run-manifests.json').write_text(json.dumps({arm:manifest(r/arm) for arm in arms},indent=2))
assert manifest_data==json.loads((r/'post-run-manifests.json').read_text())
