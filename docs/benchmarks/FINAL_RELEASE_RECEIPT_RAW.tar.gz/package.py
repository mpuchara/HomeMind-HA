import hashlib,json,pathlib,tarfile
r=pathlib.Path('/home/mpuchara/homemind-receipt-study-20261106')
d=pathlib.Path('/mnt/c/Users/mpuch/OneDrive/Dokumenty/HomeMind/HomeMind-HA-universal-232/docs/benchmarks')
folders=('profiles','initial-profiles','screen','matrix','variance','native-budget')
paths=[p for p in r.iterdir() if p.is_file() and p.name!='RAW_INDEX.json']
paths += [p for name in folders for p in (r/name).rglob('*') if p.is_file()]
index={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
(r/'RAW_INDEX.json').write_text(json.dumps(index,indent=2))
paths.append(r/'RAW_INDEX.json')
out=d/'FINAL_RELEASE_RECEIPT_RAW.tar.gz'
with tarfile.open(out,'w:gz') as archive:
 for p in sorted(paths):archive.add(p,arcname=str(p.relative_to(r)),recursive=False)
sha=hashlib.sha256(out.read_bytes()).hexdigest()
(out.with_name(out.name+'.sha256')).write_text(sha+'  '+out.name+'\n')
(d/'FINAL_RELEASE_RECEIPT_SUMMARY.json').write_bytes((r/'summary.json').read_bytes())
print(len(paths),'entries',out.stat().st_size,'bytes',sha)
