import hashlib,json,subprocess,sys
from pathlib import Path
r=Path('/home/mpuchara/homemind-receipt-study-20261106')
out=r/'native-budget';out.mkdir()
p=r/'budget-detail-probe.py'
(out/'protocol.json').write_text(json.dumps(dict(diagnostic_only=True, source='9c245577727c93ede3c59100f11844bf336acb1a', probe_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), ticks=24,period=.4,fanout=16, extra_overhead=True),indent=2))
for name,scale in [('small50','50:10'),('normal','1000:200')]:
 cmd=[sys.executable,str(p),'--profile-storage-budget','--source-root',str(r/'before'),'--harness',str(r/'before/tools/benchmark_qualified_evidence.py'),'--profile-output',str(out/(name+'.profile.json')),'--cases',scale,'--modes','normal','--ticks','24','--period','.4','--fanout','16','--output',str(out/(name+'.jsonl'))]
 with (out/(name+'.log')).open('x') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=420).returncode
 (out/(name+'.receipt.json')).write_text(json.dumps(dict(command=cmd,exit_code=code)))
 print(name,code,flush=True)
 if code:raise SystemExit(code)
